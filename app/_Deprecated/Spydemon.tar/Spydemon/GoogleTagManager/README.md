# Magento 2 — Google Tag Manager

## Aim of the module

This module implements directives dictated by Google on its [quick start guide](https://developers.google.com/tag-manager/quickstart) in order to enable GTM on your Magento website.

Indeed, we inject the following JavaScript as close to the opening `<head>` tag as possible on every page of your Magento website:

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-XXXX');</script>
    <!-- End Google Tag Manager -->

We also add the following snippet immediately after the opening `<body>` tag on every page of your Magento website in order to track also customers that don't support JavaScript.

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXX"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

### Configuration of the module

We add a new _Google Tag Manager_ section in the _Sales_ → _Google API_ store configuration of the back office.
It contains two fields:
 * `Enabled`: if set to _No_, this module will render nothing,
 * `Container ID`: the identifier provided by Google for isolating your website. It should be something like `GTM-XXXX`.
 
### How can I find my API key?

You have to go on [Google Tag Manager website](https://tagmanager.google.com), to log in with your Google account and to copy the _Container ID_ of the container that will represent your Magento website.

## What you still have to do

Nothing. You just have to install the module and to configure your `API key` as explained in the section above.

## Compatibility

This module was tested on the Magento versions that follows.

| Version | State |
| ------- | ----- |
| 2.3.5-p1 | Works |
| 2.3.5-p2 | Works |
| 2.3.6 | Works |
| 2.4.1 | Works |

## How to install it

From Magento marketplace?

## Help appreciated

If you like this module and find a bug or an enhancement, don't hesitate to fill an issue, or even better: a pull request. 😀
