//console.log("drinux");

window.dataLayer = window.dataLayer || []

require(['jquery', 'sjcl'],function($, sjcl){


    var $home_jalavista1;
    var $home_jalavista2;
    var $home_jalavista3;

    var $shown_home_jalavista1;
    var $shown_home_jalavista2;
    var $shown_home_jalavista3;

    var $catalog_category;
    var $shown_catalog_category;

    var $catalog_search;
    var $shown_catalog_search;

    var owl_prods_relacionados;
    var $shown_prods_relacionados;

    var $wish_list;
    var $shown_wish_list;

    var class_gaming            = ".home-novedades .ltabs-items-129 .ltabs-items-inner";
    var class_funko             = ".home-novedades .ltabs-items-281 .ltabs-items-inner";
    var class_coleccionables    = ".home-novedades .ltabs-items-114 .ltabs-items-inner";
    var class_audio             = ".home-novedades .ltabs-items-179 .ltabs-items-inner";
    var class_electronica       = ".home-novedades .ltabs-items-173 .ltabs-items-inner";
    var class_pop               = ".home-novedades .ltabs-items-212 .ltabs-items-inner";//.ltabs-items-inner

    var class_promociones         = ".home-promociones .product-slider";
    var class_sillas_gamer        = ".home-sillas-gamer .ltabs-items-inner";

    var class_ex_online_laptops   = ".home-exclusivo-online .ltabs-items-760 .ltabs-items-inner";
    var class_ex_online_celulares = ".home-exclusivo-online .ltabs-items-797 .ltabs-items-inner";
    var class_ex_online_tablets   = ".home-exclusivo-online .ltabs-items-822 .ltabs-items-inner";


    var owl_novedades_gaming;
    var owl_novedades_funko;
    var owl_novedades_coleccionables;
    var owl_novedades_audio;
    var owl_novedades_electronica;
    var owl_novedades_pop;

    var owl_promociones;
    var owl_sillas_gamer;

    var owl_ex_online_laptops;
    var owl_ex_online_celulares;
    var owl_ex_online_tablets;

    var shown_novedades_gaming;
    if(localStorage.getItem('shown_novedades_gaming')) {
        shown_novedades_gaming = JSON.parse(localStorage.getItem('shown_novedades_gaming'));
    }
    else {
        shown_novedades_gaming = [];
    }
    var shown_novedades_funko;
    if(localStorage.getItem('shown_novedades_funko')) {
        shown_novedades_funko = JSON.parse(localStorage.getItem('shown_novedades_funko'));
    }
    else {
        shown_novedades_funko = [];
    }
    var shown_novedades_coleccionables;
    if(localStorage.getItem('shown_novedades_coleccionables')) {
        shown_novedades_coleccionables = JSON.parse(localStorage.getItem('shown_novedades_coleccionables'));
    }
    else {
        shown_novedades_coleccionables = [];
    }
    var shown_novedades_audio;
    if(localStorage.getItem('shown_novedades_audio')) {
        shown_novedades_audio = JSON.parse(localStorage.getItem('shown_novedades_audio'));
    }
    else {
        shown_novedades_audio = [];
    }
    var shown_novedades_electronica;
    if(localStorage.getItem('shown_novedades_electronica')) {
        shown_novedades_electronica = JSON.parse(localStorage.getItem('shown_novedades_electronica'));
    }
    else {
        shown_novedades_electronica = [];
    }
    var shown_novedades_pop;
    if(localStorage.getItem('shown_novedades_pop')) {
        shown_novedades_pop = JSON.parse(localStorage.getItem('shown_novedades_pop'));
    }
    else {
        shown_novedades_pop = [];
    }

    var shown_promociones;
    if(localStorage.getItem('shown_promociones')) {
        shown_promociones = JSON.parse(localStorage.getItem('shown_promociones'));
    }
    else {
        shown_promociones = [];
    }
    var shown_sillas_gamer;
    if(localStorage.getItem('shown_sillas_gamer')) {
        shown_sillas_gamer = JSON.parse(localStorage.getItem('shown_sillas_gamer'));
    }
    else {
        shown_sillas_gamer = [];
    }
    var shown_ex_online_laptops;
    if(localStorage.getItem('shown_ex_online_laptops')) {
        shown_ex_online_laptops = JSON.parse(localStorage.getItem('shown_ex_online_laptops'));
    }
    else {
        shown_ex_online_laptops = [];
    }
    var shown_ex_online_celulares;
    if(localStorage.getItem('shown_ex_online_celulares')) {
        shown_ex_online_celulares = JSON.parse(localStorage.getItem('shown_ex_online_celulares'));
    }
    else {
        shown_ex_online_celulares = [];
    }
    var shown_ex_online_tablets;
    if(localStorage.getItem('shown_ex_online_tablets')) {
        shown_ex_online_tablets = JSON.parse(localStorage.getItem('shown_ex_online_tablets'));
    }
    else {
        shown_ex_online_tablets = [];
    }

    var jalavista1;
    var jalavista2;
    var jalavista3;

    var shown_banner_principal;
    if(localStorage.getItem('shown_banner_principal')) {
        shown_banner_principal = JSON.parse(localStorage.getItem('shown_banner_principal'));
    }
    else {
        shown_banner_principal = [];
    }

    var owl_banner_principal;

    $(window).ready(function() {
        //console.log('ready');

        setTimeout(function() {
            var clientId = getClientID();

            if( $('.customer-welcome').length ){
                var cusid = $(".cusid")[0].innerHTML;
                var encrypted =sjcl.hash.sha256.hash(cusid);
                var hash = sjcl.codec.hex.fromBits(encrypted);

                dataLayer.push({
                    'loginStatus': 'Sesión iniciada',
                    'clientid': clientId,
                    'userID': hash,
                });
            }
            else{
                dataLayer.push({
                    'loginStatus': 'Sesión no iniciada',
                    'clientid': clientId,
                });
            }

            $('#top-cart-btn-checkout:not(.procesado)').on('click', function (event) {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Realizar Pedido',
                    'label': 'Pop-up Carrito de Compras'
                });

                $(this).addClass("procesado");
            });

        }, 1000);

    });

    //$(window).load(function() {
    $(window).on('load',function(){

        jalavista1 = $('.home-jalavista1');
        jalavista2 = $('.home-jalavista2');
        jalavista3 = $('.home-jalavista3');

        //console.log('load');
        $home_jalavista1 = $('.home-jalavista1 .banner-1 .row .col-lg-4');
        var size = $home_jalavista1.length;
        $shown_home_jalavista1 = Array(size).fill(0);

        $home_jalavista2 = $('.home-jalavista2 .banner-1 .row .col-lg-4');
        size = $home_jalavista2.length;
        $shown_home_jalavista2 = Array(size).fill(0);

        $home_jalavista3 = $('.home-jalavista3 .banner-1 .row .col-lg-4');
        size = $home_jalavista3.length;
        $shown_home_jalavista3 = Array(size).fill(0);

        $catalog_category = $('.catalog-category-view .product-items .item');
        size = $catalog_category.length;
        $shown_catalog_category = Array(size).fill(0);

        $catalog_search = $('.catalogsearch-result-index .product-items .item');
        size = $catalog_search.length;
        $shown_catalog_search = Array(size).fill(0);

        if(localStorage.getItem('shown_promociones')) {
            shown_promociones = JSON.parse(localStorage.getItem('shown_promociones'));
        }
        else {
            shown_promociones = [];
            var $items = $(class_promociones + " .owl-item:not(.cloned)");
            var size = $items.length;
            var mostrados = Array(size).fill(0);
            shown_promociones = mostrados;
            localStorage.setItem('shown_promociones', JSON.stringify(shown_promociones));
            //console.log(shown_promociones);
        }


        owl_banner_principal = $(".home-banner-principal .owl-carousel");
        owl_banner_principal.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_banner_principal = mostrados;
            localStorage.setItem('shown_banner_principal', JSON.stringify(shown_banner_principal));

            var items = $(".home-banner-principal .owl-carousel .owl-item:not(.cloned)");

            if( shown_banner_principal[0] == 0 && isOnScreen(items[0]) ){
                var $position = 1;
                var banner_url_img = $(items[0]).find("img").attr('src');
                var banner_name = $(items[0]).find("a").attr('title');

                dataLayer.push({
                    'event': 'promotionView',
                    'ecommerce': {
                        'promoView': {
                            'promotions': [{
                                'id': 'HM-' + $position,
                                'name': banner_name,
                                'position': 'Home Banner Principal - ' + $position,
                                'creative': banner_url_img
                            }]
                        }
                    }
                });
                shown_banner_principal[0] = 1;
            }

        });

        owl_banner_principal.on('changed.owl.carousel', function(event) {
            var count = event.item.count;
            var position = event.item.index;

            var src = $(event.target).find(".owl-item").eq(position).find("img").attr('src');
            var name = $(event.target).find(".owl-item").eq(position).find("a").attr('title');

            if( position != 0 && position != null ){
                position = event.item.index - Math.floor((count+1)/2);
                position = position + 1;
                if( position == 0 ){
                    position = count;
                }
                //console.log("pos=" + position);
                //console.log(position);
                if( shown_banner_principal[position-1] == 0 && isOnScreen(event.target) ) {
                    //console.log('si');
                    dataLayer.push({
                        'event': 'promotionView',
                        'ecommerce': {
                            'promoView': {
                                'promotions': [{
                                    'id': 'HM-' + position,
                                    'name': name,
                                    'position': 'Home - Banner principal - ' + position,
                                    'creative': src
                                }]
                            }
                        }
                    });
                    shown_banner_principal[position-1] = 1;
                }
            }
        });
        owl_banner_principal.on('click', '.item', function (event) {
            var $items = $(".home-banner-principal .owl-carousel .owl-item:not(.cloned)");
            var $position = $items.length;
            $items.each(function( index, element ) {
                if( $(element).hasClass('active') ){
                    $position = index + 1;
                }
            });
            //console.log($position);
            var src = $(this).find("img").attr('src');
            var name = $(this).find("a").attr('title');
            dataLayer.push({
                'event': 'promotionClick',
                'ecommerce': {
                    'promoClick': {
                        'promotions': [
                            {
                                'id': 'HM-' + $position,
                                'name': name,
                                'position': 'Home - Banner principal - ' + $position,
                                'creative': src
                            }]
                    }
                }
            });
        });

        $('.home-jalavista1 .banner-image a').on('click', function (event) {
            var src = $(this).find("img").attr('src');
            var name = $(this).attr('title');
            var $items = $(".home-jalavista1 .banner-image a");
            var $position = -1;
            $items.each(function( index, element ) {
                if( $(element).attr('title') == name ){
                    $position = index + 1;
                }
            });
            dataLayer.push({
                'event': 'promotionClick',
                'ecommerce': {
                    'promoClick': {
                        'promotions': [
                            {
                                'id': 'JV1-' + $position,
                                'name': name,
                                'position': 'Home - Banner Novedades - ' + $position,
                                'creative': src
                            }]
                    }
                }
            });
        });
        $('.home-jalavista2 .banner-image a').on('click', function (event) {
            var src = $(this).find("img").attr('src');
            var name = $(this).attr('title');
            var $items = $(".home-jalavista2 .banner-image a");
            var $position = -1;
            $items.each(function( index, element ) {
                if( $(element).attr('title') == name ){
                    $position = index + 1;
                }
            });
            dataLayer.push({
                'event': 'promotionClick',
                'ecommerce': {
                    'promoClick': {
                        'promotions': [
                            {
                                'id': 'JV2-' + $position,
                                'name': name,
                                'position': 'Home - Banner Promociones - ' + $position,
                                'creative': src
                            }]
                    }
                }
            });
        });
        $('.home-jalavista3 .banner-image a').on('click', function (event) {
            var src = $(this).find("img").attr('src');
            var name = $(this).attr('title');
            var $items = $(".home-jalavista3 .banner-image a");
            var $position = -1;
            $items.each(function( index, element ) {
                if( $(element).attr('title') == name ){
                    $position = index + 1;
                }
            });
            dataLayer.push({
                'event': 'promotionClick',
                'ecommerce': {
                    'promoClick': {
                        'promotions': [
                            {
                                'id': 'JV3-' + $position,
                                'name': name,
                                'position': 'Home - Promociones - ' + $position,
                                'creative': src
                            }]
                    }
                }
            });
        });

        owl_novedades_gaming =          $(class_gaming);
        owl_novedades_funko =           $(class_funko);
        owl_novedades_coleccionables =  $(class_coleccionables);
        owl_novedades_audio =           $(class_audio);
        owl_novedades_electronica =     $(class_electronica);
        owl_novedades_pop =             $(class_pop);

        owl_promociones         = $(class_promociones);
        owl_sillas_gamer        = $(class_sillas_gamer);

        owl_ex_online_laptops   = $(class_ex_online_laptops);
        owl_ex_online_celulares = $(class_ex_online_celulares);
        owl_ex_online_tablets   = $(class_ex_online_tablets);

        owl_novedades_gaming.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_gaming = mostrados;
            localStorage.setItem('shown_novedades_gaming', JSON.stringify(shown_novedades_gaming));

            var $active_items = $(class_gaming + " .owl-item.active");

            var product_impressions = new Array();
            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;
                //console.log("pos1="+position);

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Gaming',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Gaming',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_gaming[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_gaming[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_funko.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_funko = mostrados;
            localStorage.setItem('shown_novedades_funko', JSON.stringify(shown_novedades_funko));

            var $active_items = $(class_funko + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Funko',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Funko',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_funko[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_funko[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_coleccionables.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_coleccionables = mostrados;
            localStorage.setItem('shown_novedades_coleccionables', JSON.stringify(shown_novedades_coleccionables));

            var $active_items = $(class_coleccionables + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Coleccionables',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Coleccionables',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_coleccionables[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_coleccionables[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }
        });
        owl_novedades_audio.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_audio = mostrados;
            localStorage.setItem('shown_novedades_audio', JSON.stringify(shown_novedades_audio));

            var $active_items = $(class_audio + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Audio',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Audio',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_audio[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_audio[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_electronica.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_electronica = mostrados;
            localStorage.setItem('shown_novedades_electronica', JSON.stringify(shown_novedades_electronica));

            var $active_items = $(class_electronica + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Electrónica/Tecnología',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Electrónica/Tecnología',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_electronica[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_electronica[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_pop.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_novedades_pop = mostrados;
            localStorage.setItem('shown_novedades_pop', JSON.stringify(shown_novedades_pop));

            var $active_items = $(class_pop + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Cultura Pop',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Cultura Pop',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_pop[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_pop[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_promociones.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_promociones = mostrados;
            //console.log(shown_promociones);
            localStorage.setItem('shown_promociones', JSON.stringify(shown_promociones));
        });
        owl_sillas_gamer.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_sillas_gamer = mostrados;
            localStorage.setItem('shown_sillas_gamer', JSON.stringify(shown_sillas_gamer));
        });


        owl_ex_online_laptops.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_ex_online_laptops = mostrados;
            localStorage.setItem('shown_ex_online_laptops', JSON.stringify(shown_ex_online_laptops));

            var $active_items = $(class_ex_online_laptops + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Laptops',
                    'variant': '(not available)',
                    'list': 'Home - Exclusivo Online - Laptops',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_ex_online_laptops[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_ex_online_laptops[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_ex_online_celulares.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_ex_online_celulares = mostrados;
            localStorage.setItem('shown_ex_online_celulares', JSON.stringify(shown_ex_online_celulares));

            var $active_items = $(class_ex_online_celulares + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Celulares',
                    'variant': '(not available)',
                    'list': 'Home - Exclusivo Online - Celulares y smartphones',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_ex_online_celulares[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_ex_online_celulares[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_ex_online_tablets.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            shown_ex_online_tablets = mostrados;
            localStorage.setItem('shown_ex_online_tablets', JSON.stringify(shown_ex_online_tablets));

            var $active_items = $(class_ex_online_tablets + " .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Tablets',
                    'variant': '(not available)',
                    'list': 'Home - Exclusivo Online - Tablets',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_ex_online_tablets[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_ex_online_tablets[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }
        });


        owl_novedades_gaming.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_gaming + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Gaming',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Gaming',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_gaming[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_gaming[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Gaming',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Gaming',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_gaming[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_gaming[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_novedades_funko.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_funko + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Funko',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Funko',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_funko[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            product_impressions.push(product_impression);
                            shown_novedades_funko[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Funko',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Funko',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_funko[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_funko[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_coleccionables.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_coleccionables + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Coleccionables',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Coleccionables',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_coleccionables[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_coleccionables[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Coleccionables',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Coleccionables',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_coleccionables[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_coleccionables[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_audio.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_audio + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Audio',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Audio',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_audio[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_audio[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Audio',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Audio',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_audio[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_audio[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_electronica.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_electronica + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Electrónica/Tecnología',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Electrónica/Tecnología',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_electronica[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_electronica[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Electrónica/Tecnología',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Electrónica/Tecnología',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_electronica[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_electronica[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_novedades_pop.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_pop + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Cultura Pop',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Cultura Pop',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_pop[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_pop[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Cultura Pop',
                            'variant': '(not available)',
                            'list': 'Home - Novedades - Cultura Pop',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_novedades_pop[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_novedades_pop[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_promociones.on('changed.owl.carousel', function(event) {
            //console.log("changed promociones");

            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }

            //console.log("pos promo=" + cposition + " size event=" + count);
            var $items = $(class_promociones + " .owl-item:not(.cloned)");
            //console.log("size promos=" + $items.length);

            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Promociones',
                            'variant': '(not available)',
                            'list': 'Home - Promociones',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_promociones[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_promociones[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Promociones',
                            'variant': '(not available)',
                            'list': 'Home - Promociones',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_promociones[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_promociones[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_sillas_gamer.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_sillas_gamer + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Sillas Gamer',
                            'variant': '(not available)',
                            'list': 'Home - Sillas Gamer',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_sillas_gamer[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_sillas_gamer[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Sillas Gamer',
                            'variant': '(not available)',
                            'list': 'Home - Sillas Gamer',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_sillas_gamer[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_sillas_gamer[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        owl_ex_online_laptops.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_ex_online_laptops + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Laptops',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Laptops',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_laptops[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_laptops[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Laptops',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Laptops',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_laptops[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_laptops[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_ex_online_celulares.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_ex_online_celulares + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Celulares y smartphones',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Celulares y smartphones',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_celulares[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_celulares[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Celulares y smartphones',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Celulares y smartphones',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_celulares[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_celulares[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });
        owl_ex_online_tablets.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var size = event.page.size;

            var count = event.item.count;
            var cposition = current - Math.floor((count+1)/2);
            cposition = cposition + 1;
            if( cposition == 0 ){
                cposition = count;
            }
            var $items = $(class_ex_online_tablets + " .owl-item:not(.cloned)");
            var product_impressions = new Array();
            $items.each(function( index, element ) {
                var position = index + 1;
                if( cposition + size <= count + 1){
                    if( position >= cposition && position < cposition + size ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Tablets',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Tablets',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_tablets[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_tablets[position-1] = 1;
                        }
                    }
                }
                else{
                    if(  ( 0 < position && position < (cposition + size) % count ) || ( cposition <= position && position < count +1 ) ){
                        var name = $(element).find(".product-item-link").html().trim();
                        var product_id = $(element).find(".price-final_price").attr('data-product-id');
                        var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento_string = '';
                        if( $(element).find('.special-price').length )         // use this if you are using class to check
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Tablets',
                            'variant': '(not available)',
                            'list': 'Home - Exclusivo Online - Tablets',
                            'position': position,
                            'dimension1': descuento_string
                        };
                        if( shown_ex_online_tablets[position-1] == 0 && isOnScreen(element) && $(element).is(":visible") ) {
                            //console.log('gaming onscreen');
                            product_impressions.push(product_impression);
                            shown_ex_online_tablets[position-1] = 1;
                        }
                    }
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });



        owl_novedades_gaming.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_gaming + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Gaming'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Gaming',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_gaming.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_gaming + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Gaming'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Gaming',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_novedades_funko.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_funko + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Funko'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Funko',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_funko.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_funko + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Funko'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Funko',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_novedades_coleccionables.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_coleccionables + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Coleccionables'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Coleccionables',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_coleccionables.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_coleccionables + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Coleccionables'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Coleccionables',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_novedades_audio.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_audio + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Audio'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Audio',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_audio.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_audio + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Audio'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Audio',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_novedades_electronica.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_electronica + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Electrónica/Tecnología'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Electrónica/Tecnología',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_electronica.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_electronica + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Electrónica/Tecnología'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Electrónica/Tecnología',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_novedades_pop.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_pop + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Cultura Pop'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Cultura Pop',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_novedades_pop.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_pop + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Novedades - Cultura Pop'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Cultura Pop',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        owl_promociones.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_promociones + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Promociones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Promociones',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_promociones.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_promociones + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Promociones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Promociones',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        owl_sillas_gamer.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_sillas_gamer + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Sillas Gamer'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Sillas Gamer',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_sillas_gamer.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_sillas_gamer + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Sillas Gamer'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Sillas Gamer',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        owl_ex_online_laptops.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_laptops + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Laptops'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Laptops',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_ex_online_laptops.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_laptops + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Laptops'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Laptops',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_ex_online_celulares.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_celulares + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Celulares y smartphones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Celulares',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_ex_online_celulares.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_celulares + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Celulares y smartphones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Celulares',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });
        owl_ex_online_tablets.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_tablets + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Tablets'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Tablets',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_ex_online_tablets.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(class_ex_online_tablets + " .owl-item:not(.cloned)");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Home - Exclusivo Online - Tablets'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Tablets',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        //Agregar al carrito de compras

        owl_novedades_gaming.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Gaming'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Gaming',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_novedades_funko.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Funko'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Funko',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_novedades_coleccionables.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Coleccionables'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Coleccionables',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_novedades_audio.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Audio'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Audio',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_novedades_electronica.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Electrónica/Tecnología'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Electrónica/Tecnología',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_novedades_pop.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Novedades - Cultura Pop'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Cultura Pop',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });

        owl_promociones.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Promociones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': 'Promociones',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_sillas_gamer.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Sillas Gamer'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Sillas Gamer',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_ex_online_laptops.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Exclusivo Online - Laptops'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Laptops',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_ex_online_celulares.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Exclusivo Online - Celulares y smartphones'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Celulares',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });
        owl_ex_online_tablets.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title .base').html().trim();
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Home - Exclusivo Online - Tablets'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': 'Tablets',
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': seccion
                        }]
                    }
                }
            });
        });

        //Agregar a Lista de Deseos y Agregar para comparar
        owl_novedades_gaming.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Gaming',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_gaming.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Gaming',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_novedades_funko.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Funko',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_funko.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Funko',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_novedades_coleccionables.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Coleccionables',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_coleccionables.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Coleccionables',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_novedades_audio.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Audio',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_audio.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Audio',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_novedades_electronica.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Electrónica/Tecnología',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_electronica.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Electrónica/Tecnología',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_novedades_pop.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Cultura Pop',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_novedades_pop.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Novedades - Cultura Pop',
                'action': 'Añadir para comparar',
                'label': name
            });
        });

        owl_promociones.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Promociones',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_promociones.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Promociones',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_sillas_gamer.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Sillas Gamer',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_sillas_gamer.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Sillas Gamer',
                'action': 'Añadir para comparar',
                'label': name
            });
        });

        owl_ex_online_laptops.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Laptops',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_ex_online_laptops.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Laptops',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_ex_online_celulares.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Celulares y smartphones',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_ex_online_celulares.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Celulares y smartphones',
                'action': 'Añadir para comparar',
                'label': name
            });
        });
        owl_ex_online_tablets.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Tablets',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_ex_online_tablets.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Exclusivo Online - Tablets',
                'action': 'Añadir para comparar',
                'label': name
            });
        });


        $('.home-categorias-populares .image-cat a').on('click', function (event) {
            var title = $(this).attr('title');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Categorías populares',
                'action': 'Seleccionar Categoría',
                'label': title
            });
        });
        $('.home-categorias-populares .cat-title a').on('click', function (event) {
            var title = $(this).attr('title');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Categorías populares',
                'action': 'Seleccionar Categoría',
                'label': title
            });
        });

        $('.home-categorias-populares .sub-cats .child-title a').on('click', function (event) {
            var title = $(this).attr('title');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home - Categorías populares',
                'action': 'Seleccionar Subcategoría',
                'label': title
            });
        });

        $('.home-categorias-destacadas .containerimg div a').on('click', function (event) {
            var title = $(this).attr('title');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Home',
                'action': 'Selección de Categorías Destacadas',
                'label': title
            });
        });

        $('.catalog-category-view .product-items .item').on('click', '.product-item-photo', function (event) {

                var $item = $(this).parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var $items = $('.catalog-category-view .product-items .item');
                var $position = -1;

                $items.each(function( index, element ) {
                    var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                    if( element_product_id == product_id ){
                        $position = index + 1;
                    }
                });

                var title = $('.page-title span').html();
                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 2){
                    category = category_items[1].innerText;
                }

                dataLayer.push({
                    'event': 'productClick',
                    'ecommerce': {
                        'click': {
                            'actionField': {'list': 'Categoría - ' + category},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': category,
                                'variant': '(not available)',
                                'position': $position ,
                                'dimension1': descuento_string
                            }]
                        }
                    }
                });

        });
        $('.catalog-category-view .product-items .item').on('click', '.product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $('.catalog-category-view .product-items .item');
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            var title = $('.page-title span').html();
            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 2){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Categoría - ' + category},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        $('.catalog-category-view .product-items .item .tocart:not(.procesado)').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title span').html().trim();
            }
            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 2){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Categoría - ' + category},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': 'Lista de Productos'
                        }]
                    }
                }
            });
            $(this).addClass("procesado");
        });
        $('.catalog-category-view .product-items .item:not(.procesadof)').on('click', '.towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var title = $('.page-title span').html();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Agregar a los favoritos',
                'label': name
            });
            $(this).addClass("procesadof");
        });
        $('.catalog-category-view .product-items .item:not(.procesadoc)').on('click', '.tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var title = $('.page-title span').html();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Añadir para comparar',
                'label': name
            });
            $(this).addClass("procesadoc");
        });

        $('.catalogsearch-result-index .product-items .item').on('click', '.product-item-photo', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $('.catalogsearch-result-index .product-items .item');
            var $position = -1;

            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            var search_key = $('.page-title span').html();
            search_key = search_key.replace('\'','');
            search_key = search_key.replace('Resultados de búsqueda para: ','');


            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Categoría - Search Result'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': search_key,
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        $('.catalogsearch-result-index .product-items .item').on('click', '.product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $('.catalogsearch-result-index .product-items .item');
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            var search_key = $('.page-title span').html();
            search_key = search_key.replace('\'','');
            search_key = search_key.replace('Resultados de búsqueda para: ','');

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Categoría - Search Result'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': search_key,
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        $('.catalogsearch-result-index .product-items .item .tocart:not(.procesado)').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var seccion = '';
            if( $('.cms-index-index').length ){
                seccion = 'Home';
            }
            else{
                seccion = $('.page-title span').html().trim();
            }
            var search_key = $('.page-title span').html();
            search_key = search_key.replace('\'','');
            search_key = search_key.replace('Resultados de búsqueda para: ','');

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Categoría - Search Result'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': search_key,
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': 'Lista de Productos'
                        }]
                    }
                }
            });
            $(this).addClass("procesado");
        });
        $('.catalogsearch-result-index .product-items .item:not(.procesadof)').on('click', '.towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - Search Result',
                'action': 'Agregar a los favoritos',
                'label': name
            });
            $(this).addClass("procesadof");
        });
        $('.catalogsearch-result-index .product-items .item:not(.procesadoc)').on('click', '.tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - Search Result',
                'action': 'Añadir para comparar',
                'label': name
            });
            $(this).addClass("procesadoc");
        });

        $('.catalog-category-view #limiter').on('change', function (e) {
            var selected = $(this).find(":selected").html().trim();
            var size = parseInt(selected);
            var old_size = $shown_catalog_category.length;
            if( size > old_size ){
                var add_array = Array(size - old_size).fill(0);
                $shown_catalog_category = $shown_catalog_category.concat(add_array);
            }
            else{
                var new_array = $shown_catalog_category.slice(0, size);
                $shown_catalog_category = new_array;
            }
        });

        $('.catalogsearch-result-index #limiter').on('change', function (e) {
            var selected = $(this).find(":selected").html().trim();
            var size = parseInt(selected);

            var old_size = $shown_catalog_search.length;
            if( size > old_size ){
                var add_array = Array(size - old_size).fill(0);
                $shown_catalog_search = $shown_catalog_search.concat(add_array);
            }
            else{
                var new_array = $shown_catalog_search.slice(0, size);
                $shown_catalog_search = new_array;
            }
        });

        $('.catalog-category-view #sorter').on('change', function (e) {
            //console.log(this);
            var title = $('.page-title span').html().trim();
            var selected = $(this).find(":selected").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Aplicar Orden',
                'label': selected
            });

        });
        $('.catalogsearch-result-index #sorter').on('change', function (e) {
            //console.log(this);
            var selected = $(this).find(":selected").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - Search Result',
                'action': 'Aplicar Orden',
                'label': selected
            });

        });

        $('.catalog-category-view .modes .mode-list').on('click', function (e) {
            //console.log(this);
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Aplicar vista de:',
                'label': 'Lista'
            });
        });
        $('.catalog-category-view .modes .mode-grid').on('click', function (e) {
            //console.log(this);
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Aplicar vista de:',
                'label': 'Parrilla'
            });
        });

        //Product List Filters

        $('.catalog-category-view .filter-options-content .items .item a').on('click', function (e) {
            //console.log(this);
            var title = $('.page-title span').html().trim();
            var filter = $(this)
                .clone()    //clone the element
                .children() //select all the children
                .remove()   //remove all the children
                .end()  //again go back to selected element
                .text();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - ' + title,
                'action': 'Aplicar filtro:',
                'label': filter.trim()
            });
        });

        $('.catalogsearch-result-index .filter-options-content .items .item a').on('click', function (e) {

            var filter = $(this)
                .clone()    //clone the element
                .children() //select all the children
                .remove()   //remove all the children
                .end()  //again go back to selected element
                .text();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Categoría - Search Result',
                'action': 'Aplicar filtro:',
                'label': filter.trim()
            });
        });

        //4.1
        var producto = $('.catalog-product-view .product-info-main');
        if( producto.length != 0){
            //console.log('producto pagina');
            var name = $(producto).find(".page-title span").html().trim();
            var product_id = $(producto).find(".price-final_price").attr('data-product-id');
            var product_price_amount = $(producto).find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(producto).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $(producto).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $(producto).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }
            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 3){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'productDetails',
                'ecommerce': {
                    'detail': {
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'dimension1': descuento_string,
                        }]
                    }
                }
            });

        }

        //4.2 Agregar producto al carrito
        $('.catalog-product-view #product-addtocart-button').on('click', function (event) {
            //console.log('click ');
            //console.log('addtocart');
            var producto_form = $('#product_addtocart_form');
            if( $(producto_form).valid() ){
                //console.log('valido');

                var $item = $(this).parent().parent().parent().parent().parent().parent();
                var name = $('.page-title span').html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )         // use this if you are using class to check
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }
                var qty = $item.find("#qty").val();

                var categories = $(".catalog-product-view .breadcrumbs .items .item:not(.home, .product)");
                var list = '';
                var category = '';
                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 2){
                    category = category_items[1].innerText;
                }

                dataLayer.push({
                    'event': 'addToCart',
                    'ecommerce': {
                        'currencyCode' : 'PEN',
                        'add': {
                            'actionField': {'list': 'Detalle de Producto - ' + category },
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': category,
                                'variant': '(not available)',
                                'quantity' : parseInt(qty),
                                'dimension1': descuento_string,
                            }]
                        }
                    }
                });
            }

        });

        $('.catalog-product-view .product-addto-links').on('click', '.towishlist:not(.procesado)', function (event) {
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de producto',
                'action': 'Agregar a los favoritos',
                'label': title
            });
            $(this).addClass("procesado");
        });
        $('.catalog-product-view .product-addto-links').on('click', '.tocompare:not(.procesado)', function (event) {
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de producto',
                'action': 'Añadir para comparar',
                'label': title
            });
            $(this).addClass("procesado");
        });

        //4.6 Producto Detalle - Impresión de productos - parte1, ver parte2
        owl_prods_relacionados = $(".catalog-product-view .products-grid .owl-carousel");
        owl_prods_relacionados.on('initialized.owl.carousel', function(event) {
            var size = event.item.count;
            var mostrados = Array(size).fill(0);
            $shown_prods_relacionados = mostrados;
        });

        //4.6 - Producto detalle - Impression de productos - parte2 - ver parte 1
        owl_prods_relacionados.on('changed.owl.carousel', function(event) {
            var current = event.item.index;
            var $active_items = $(".catalog-product-view .products-grid .owl-carousel .owl-item.active");
            var product_impressions = new Array();

            $active_items.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }
                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 3){
                    category = category_items[1].innerText;
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': category,
                    'variant': '(not available)',
                    'list': 'Detalle de producto - Productos relacionados',
                    'position': position,
                    'dimension1': descuento_string
                };

                if( $shown_prods_relacionados[position-1] == 0 && isOnScreen(element) ) {
                    product_impressions.push(product_impression);
                    $shown_prods_relacionados[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

        });

        //4.7 Producto Detalle - Productos Relacionados
        owl_prods_relacionados.on('click', '.item .image-product', function (event) {

            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(".catalog-product-view .products-grid .owl-carousel .owl-item");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 3){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Detalle de Producto - Productos relacionados'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });

        });
        owl_prods_relacionados.on('click', '.item .product-item-link', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(".catalog-product-view .products-grid .owl-carousel .owl-item");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 3){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Detalle de Producto - Productos relacionados'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        //Agregar al carrito de compras
        owl_prods_relacionados.on('click', '.item .tocart', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-final_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var category_items = $('.breadcrumbs .items .item');
            var category = '(not available)';
            if( category_items.length >= 3){
                category = category_items[1].innerText;
            }

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'currencyCode' : 'PEN',
                    'add': {
                        'actionField': {'list': 'Detalle de producto - Productos relacionados'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': category,
                            'variant': '(not available)',
                            'quantity' : 1,
                            'dimension1': descuento_string,
                            'dimension2': 'Detalle de producto'
                        }]
                    }
                }
            });
        });

        //Agregar a Lista de Deseos y Agregar para comparar
        owl_prods_relacionados.on('click', '.item .towishlist', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de producto - Productos relacionados',
                'action': 'Agregar a los favoritos',
                'label': name
            });
        });
        owl_prods_relacionados.on('click', '.item .tocompare', function (event) {
            var $item = $(this).parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de producto - Productos relacionados',
                'action': 'Añadir para comparar',
                'label': name
            });
        });

        //5.1 Carrito de Compras - Ver y editar carrito
        /*
        $('#minicart-content-wrapper .block-content .actions .secondary .viewcart').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Ver y Editar Mi Carrito',
                'label': '(not available)'
            });
            let _url = $(this).attr('href');
            window.location.href = _url;
        });
        */
        $('body').on('click', '.action.viewcart:not(.procesado)', function(e) {
            let _url = $(this).attr('href');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Ver y Editar Mi Carrito',
                'label': '(not available)',
                /*'eventCallback' : function() {
                    setTimeout(() => {
                        window.location.href = _url;
                    }, 1000);
                }*/
            });
            $(this).addClass("procesado");
            window.location.href = _url;
            return false;
        });


        //5.2 Carrito de Compras - Realizar pedido
        /*$('#top-cart-btn-checkout').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Realizar Pedido',
                'label': '(not available)'
            });
        });*/



        $('body').on('click', '.action.checkout:not(.procesado)', function(e) {
            //let _url = $(this).attr('href');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Realizar Pedido',
                'label': 'Pop-up Carrito de Compras'
            });
            //window.location.href = _url;
            //return false;
            $(this).addClass("procesado");
        });

        $('.cart-summary .checkout .action.primary.checkout:not(.procesado)').on('click', function(e) {
            //let _url = $(this).attr('href');
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Realizar Pedido',
                'label': 'Carrito de Compras'
            });
            //window.location.href = _url;
            //return false;
            $(this).addClass("procesado");
        });



        // 4.5 Producto Detalle - Agregar al carrito

        $('#smcqp-container .smcqp-continue:not(.procesado)').on('click', function (event) {
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de Producto',
                'action': 'Añadiste a tu carrito de compras',
                'label': 'Continuar'
            });
            $(this).addClass("procesado");
        });

        $('#smcqp-container .smcqp-view-cart:not(.procesado)').on('click', function (event) {
            var title = $('.page-title span').html().trim();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Detalle de Producto',
                'action': 'Añadiste a tu carrito de compras',
                'label': 'Ir al carrito'
            });
            $(this).addClass("procesado");
        });


        //5.3 Carrito de Compras - Aplicar cupón
        $('#discount-coupon-form .actions-toolbar .primary button').on('click', function (event) {
            var $form = $(this).parent().parent().parent().parent();
            var coupon = $form.find("#coupon_code").val();
            //console.log("cupon='" + coupon + "'");
            if( coupon !== ""){
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Descuento satisfactorio',
                    'label': coupon
                });
            }

        });

        //5.4 Carrito de Compras - A la lista de deseos
        $('.checkout-cart-index #shopping-cart-table .item .item-actions .action-towishlist:not(.procesado)').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var product_name = $item.find(".product-item-name a").html();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Agregar a los favoritos',
                'label': product_name
            });
            $(this).addClass("procesado");
        });

        //5.5 Carrito de Compras -Seleccionar Editar
        $('.checkout-cart-index #shopping-cart-table .item .item-actions .action-edit').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var product_name = $item.find(".product-item-name a").html();
            

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Editar',
                'label': product_name
            });
        });

        //5.6 Carrito de Compras -Eliminar producto del carrito
        $('.checkout-cart-index #shopping-cart-table .item .item-actions .action-delete:not(.procesadodel)').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var product_name = $item.find(".product-item-name a").html();
            var produt_price = $item.find(".cart-price .price").html();
            var product_qty = $item.find(".qty .input-text").val();

            dataLayer.push({
                'event': 'removeFromCart',
                'ecommerce': {
                    'remove': {
                        'products': [{
                            'name': product_name,
                            'id': '(not available)',
                            'price': produt_price,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'quantity': product_qty,
                            'dimension1': '(not available)',
                            'dimension2': 'Carrito de compras'
                        }]
                    }
                }
            });

            $(this).addClass("procesadodel");

        });

        //5.7 Carrito de Compras - Continuar
        $('.form-cart .actions .continue').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Continuar comprando',
                'label': '(not available)'
            });
        });

        //5.8 Carrito de Compras - Actualizar carrito
        $('.form-cart .actions .update').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Carrito de Compras',
                'action': 'Actualizar carrito',
                'label': '(not available)'
            });
        });

        //6.2
        //#checkout-step-shipping_method
        $("#shipping-method-buttons-container .primary .continue:not(.procesado)").on('click', function (event) {
            var metodo = $("#checkout-step-shipping_method .table-checkout-shipping-method .row .col-method .radio:checked");
            var row = metodo.parent().parent();

            var precio = $(row).find('.col-price .price .price').html().trim();
            var tipo_metodo = $(row).find('.col-carrier').html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Checkout - Envío',
                'action': 'Siguiente',
                'label': precio + '-' + tipo_metodo,
            });
            
            $(this).addClass("procesado");
        });

        //7.4 Marcas de CheckOut - Pago - Compra validada exitosamente (Pago efectivo)
        if( $('.checkout-onepage-success ').length != 0 ){

            $("#myiframe").contents().find("#myContent")

        }


        //8.1 Barra de navegacion superior - Selección de categorías
        $(".sm_megamenu_wrapper_vertical_menu .sm_megamenu_lv1 .sm_megamenu_head").on('click', function (event) {

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Menú de Categorías',
                'action': 'Seleccionar Categoría',
                'label': $(this).find('.sm_megamenu_title').html()
            });
        });

        $('.sm_megamenu_wrapper_vertical_menu .sm_megamenu_title_lv-2').on('click', function (event) {
            $parent = $(this).parent().parent().parent();
            if( $parent.hasClass('sm_megamenu_title') ){
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Menú de Categorías',
                    'action': 'Seleccionar Tipo de producto',
                    'label': $(this).html()
                });
            }
            else{

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Menú de Categorías',
                    'action': 'Seleccionar Subcategoria',
                    'label': $(this).html()
                });
            }
        });

        //8.2 Selección de botones superiores:
        $('.sm_megamenu_wrapper_horizontal_menu .sm_megamenu_lv1 .sm_megamenu_head').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Botones Superiores',
                'action': 'Opciones de navegador',
                'label': $(this).find('.sm_megamenu_title').html()
            });
        });
        $('.customer-action .customer-links .header li a').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Botones Superiores',
                'action': 'Opciones de navegador',
                'label': $(this).html().trim()
            });
        });

        //11.1 Barra de navegación inferior - Selección de Opciones:
        $('.social-footer ul li a').on('click', function (event) {

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Pie de Página',
                'action': 'Seleccionar Redes Sociales',
                'label': $(this).find('span').html()
            });

        });

        $('.block-footer .block-footer-content ul li a').on('click', function (event) {
            var $parent = $(this).parent().parent().parent().parent();
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Pie de Página',
                'action': 'Seleccionar ' + $parent.find('.block-footer-title').html(),
                'label': $(this).html().trim()
            });
        });

        //11.2
        $('form .newsletter-content .action-button .subscribe').on('click', function (event) {

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Pie de Página',
                'action': 'Intención de Suscripción',
                'label': '(not available)'
            });

            /*
            var email = $('#newsletter-footer').val();

            if( email != ''){
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Pie de Página',
                    'action': 'Suscripción satisfactoria',
                    'label': '(not available)'
                });
            }*/

        });

        //11.3
        //11.4
        $('body').on('click', '.action.subscribe', function(e) {
            let _url =  $(this).parent().parent().parent().attr('action');
            let _email =  $(this).parent().parent().parent().find('#newsletter-footer');

            if($('#newsletter-footer-error')) {
                $('#newsletter-footer-error').empty();
                $('#newsletter-footer-error').remove();
            }

            if( emailIsValid(_email.val()) ) {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Pie de Página',
                    'action': 'Suscripción satisfactoria',
                    'label': '(not available)'
                });

                $.ajax({
                    type: 'POST',
                    url: _url,
                    data: { email: _email.val() },
                    success:function(data) {
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    }
                });
            }
            else {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Pie de Página',
                    'action': 'Suscripción fallida',
                    'label': '(not available)'
                });
                let _inputBox = $(this).parent().parent().parent().find('.input-box');
                _inputBox.append('<div for="newsletter-footer" generated="true" class="mage-error" id="newsletter-footer-error">Introduzca una dirección válida de correo electrónico (Ex: johndoe@domain.com).</div>');
            }

            return false;
        });

        function emailIsValid (email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
        }

        //12.1 Regístrate / Inicia Sesión
        $('.customer-account-login .form-login #send2').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Iniciar sesión',
                'label': 'Iniciar sesión'
            });
        });
        $('.customer-account-login .form-login .secondary .remind').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Iniciar sesión',
                'label': '¿Olvidaste tu contraseña?'
            });
        });
        $('.customer-account-login .block-new-customer .primary .create').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Iniciar sesión',
                'label': 'Regístrate'
            });
        });

        $('.customer-account-create .form-create-account .primary .submit').on('click', function (event) {
            var form = $('#form-validate');
            if( $(form).valid() ){
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Página de Usuario',
                    'action': 'Regístrate',
                    'label': 'Regístrate'
                });
            }

        });
        $('.customer-account-create .form-create-account .secondary .back').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Regístrate',
                'label': 'Atrás'
            });
        });

        $('.customer-account-forgotpassword .form .primary .submit').on('click', function (event) {
            var form = $('#form-validate');
            if( $(form).valid() ){
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Página de Usuario',
                    'action': '¿Olvidaste tu contraseña?',
                    'label': 'Restablecer mi contraseña'
                });
            }

        });
        $('.customer-account-forgotpassword .form .secondary .back').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': '¿Olvidaste tu contraseña?',
                'label': 'Retroceder'
            });
        });

        //12.2 -
        $('.account .sidebar-main #account-nav .items .item a').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Navegador de Cuenta',
                'label': $(this).html()
            });
        });

        //12.3 -
        $('.customer-account-index .block-dashboard-info .box-information .box-actions .edit').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Editar información de contacto'
            });
        });
        $('.customer-account-index .block-dashboard-info .box-information .box-actions .change-password').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Cambiar la contraseña'
            });
        });
        $('.customer-account-index .block-dashboard-info .box-newsletter .box-actions .edit').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Editar Boletines informativos'
            });
        });
        $('.customer-account-index .block-dashboard-addresses .block-title .edit').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Gestionar direcciones'
            });
        });
        $('.customer-account-index .block-dashboard-addresses .box-billing-address .box-actions .edit').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Editar dirección de facturación por defecto'
            });
        });
        $('.customer-account-index .block-dashboard-addresses .box-shipping-address .box-actions .edit').on('click', function (event) {
            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Opciones de Cuenta',
                'label': 'Editar dirección de envío predeterminado'
            });
        });

        //12.4
        $wish_list = $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item');
        size = $wish_list.length;
        $shown_wish_list = Array(size).fill(0);

        //12.5 -
        $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item').on('click', '.product-item-photo', function (event) {
            var $item = $(this).parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-configured_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-configured_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(".wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item");

            //console.log('items');
            //console.log($items);
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-box").attr('data-product-id');
                //('prod_id');
                //console.log(element_product_id);
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Mi Lista de Deseos'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'position': $position ,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item .product-item-link').on('click', function (event) {

            var $item = $(this).parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-configured_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-configured_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var $items = $(".wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item");
            var $position = -1;
            $items.each(function( index, element ) {
                var element_product_id = $(element).find(".price-box").attr('data-product-id');
                if( element_product_id == product_id ){
                    $position = index + 1;
                }
            });

            dataLayer.push({
                'event': 'productClick',
                'ecommerce': {
                    'click': {
                        'actionField': {'list': 'Mi Lista de Deseos'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'position': $position,
                            'dimension1': descuento_string
                        }]
                    }
                }
            });
        });

        //12.6 -
        $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item .tocart').on('click', function (event) {

            var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();
            var product_id = $item.find(".price-configured_price").attr('data-product-id');
            var product_price_amount = $item.find(".price-configured_price .price-wrapper").attr('data-price-amount');
            var descuento_string = '';
            if( $(this).find('.special-price').length )         // use this if you are using class to check
            {
                var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                product_price_amount = product_special_price;
                var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                descuento_string = Math.round(descuento) + '% OFF';
            }
            else{
                descuento_string = '0% OFF';
            }

            var qty = $item.find(".box-tocart .qty .control .qty").val();

            dataLayer.push({
                'event': 'addToCart',
                'ecommerce': {
                    'add': {
                        'actionField': {'list': 'Mi Lista de Deseos'},
                        'products': [{
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount ,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'quantity': parseInt(qty),
                            'dimension1': descuento_string,
                            'dimension2': 'Usuario'
                        }]
                    }
                }
            });
        });
        $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item .product-item-actions .edit').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Editar Productos en Mi Lista de Deseos:',
                'label': name
            });
        });
        $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item .product-item-actions .delete').on('click', function (event) {
            var $item = $(this).parent().parent().parent().parent();
            var name = $item.find(".product-item-link").html().trim();

            dataLayer.push({
                'event': 'virtualEvent',
                'category': 'Página de Usuario',
                'action': 'Eliminar Productos en Mi Lista de Deseos:',
                'label': name
            });
        });

        //Gerson

        $('body').on('click', '.form-edit-account .action.save', function(e) {
            let _fchecks = [];
            let _fields = $('.form-edit-account').serializeArray();

            for(let i = 0; i < _fields.length; i++) {
                if(_fields[i].name == 'form_key') { _fields.splice(i, 1); }
            }

            //sendDataFormErrors(_fields);

        });

        $('body').on('click', '.form-create-account .action.submit', function(e) {

            let _fchecks = [];
            let _fields = $('.form-create-account').serializeArray();

            for(let i = 0; i < _fields.length; i++) {
                if(_fields[i].name == 'form_key') { _fields.splice(i, 1); }
                if(_fields[i].name == 'success_url') { _fields.splice(i, 1); }
                if(_fields[i].name == 'error_url') { _fields.splice(i, 1); }
            }

            //sendDataFormErrors(_fields);

        });

        $('body').on('click', '.form.contact .action.submit', function(e) {
            let _fchecks = [];
            let _fields = $('.form.contact').serializeArray();

            for(let i = 0; i < _fields.length; i++) {
                if(_fields[i].name == 'hideit') { _fields.splice(i, 1); }
            }

            //sendDataFormErrors(_fields);

        });

        /*
        function sendDataFormErrors(_fields) {
            let _fchecks = [];
            for(let f of _fields) {
                if(f.value == '') {
                    _fchecks.push(f);
                    dataLayer.push({
                        'event': 'virtualEvent',
                        'category': 'Checkout - Envío',
                        'action': 'Errores en formulario',
                        'label': `${f.name}`
                    });
                }
            }
        }*/

    });

    $.ajaxSetup({
        beforeSend: function() {
            // show progress spinner
        },
        complete: function(result) {

            $catalog_category = $('.catalog-category-view .product-items .item');
            $catalog_search = $('.catalogsearch-result-index .product-items .item');

            $('.catalog-category-view .product-items .item').on('click', '.product-item-photo', function (event) {

                var $item = $(this).parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var $items = $('.catalog-category-view .product-items .item');
                var $position = -1;

                $items.each(function( index, element ) {
                    var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                    if( element_product_id == product_id ){
                        $position = index + 1;
                    }
                });

                var title = $('.page-title span').html();
                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 2){
                    category = category_items[1].innerText;
                }

                dataLayer.push({
                    'event': 'productClick',
                    'ecommerce': {
                        'click': {
                            'actionField': {'list': 'Categoría - ' + category},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': category,
                                'variant': '(not available)',
                                'position': $position ,
                                'dimension1': descuento_string
                            }]
                        }
                    }
                });

            });
            $('.catalog-category-view .product-items .item').on('click', '.product-item-link', function (event) {
                var $item = $(this).parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )         // use this if you are using class to check
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var $items = $('.catalog-category-view .product-items .item');
                var $position = -1;
                $items.each(function( index, element ) {
                    var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                    if( element_product_id == product_id ){
                        $position = index + 1;
                    }
                });

                var title = $('.page-title span').html();
                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 2){
                    category = category_items[1].innerText;
                }

                dataLayer.push({
                    'event': 'productClick',
                    'ecommerce': {
                        'click': {
                            'actionField': {'list': 'Categoría - ' + category},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': category,
                                'variant': '(not available)',
                                'position': $position,
                                'dimension1': descuento_string
                            }]
                        }
                    }
                });
            });

            $('.catalog-category-view .product-items .item .tocart:not(.procesado)').on('click', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )         // use this if you are using class to check
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var seccion = '';
                if( $('.cms-index-index').length ){
                    seccion = 'Home';
                }
                else{
                    seccion = $('.page-title span').html().trim();
                }

                var category_items = $('.breadcrumbs .items .item');
                var category = '(not available)';
                if( category_items.length >= 2){
                    category = category_items[1].innerText;
                }

                dataLayer.push({
                    'event': 'addToCart',
                    'ecommerce': {
                        'currencyCode' : 'PEN',
                        'add': {
                            'actionField': {'list': 'Categoría - ' + category},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': category,
                                'variant': '(not available)',
                                'quantity' : 1,
                                'dimension1': descuento_string,
                                'dimension2': 'Lista de Productos'
                            }]
                        }
                    }
                });
                $(this).addClass("procesado");
            });

            $('.catalog-category-view .product-items .item:not(.procesadof)').on('click', '.towishlist', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var title = $('.page-title span').html();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Agregar a los favoritos',
                    'label': name
                });

                $(this).addClass("procesadof");
            });
            $('.catalog-category-view .product-items .item:not(.procesadoc)').on('click', '.tocompare', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var title = $('.page-title span').html();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Añadir para comparar',
                    'label': name
                });
                $(this).addClass("procesadoc");
            });

            $('.catalogsearch-result-index .product-items .item').on('click', '.product-item-photo', function (event) {

                var $item = $(this).parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var $items = $('.catalogsearch-result-index .product-items .item');
                var $position = -1;

                $items.each(function( index, element ) {
                    var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                    if( element_product_id == product_id ){
                        $position = index + 1;
                    }
                });

                var search_key = $('.page-title span').html();
                search_key = search_key.replace('\'','');
                search_key = search_key.replace('Resultados de búsqueda para: ','');

                dataLayer.push({
                    'event': 'productClick',
                    'ecommerce': {
                        'click': {
                            'actionField': {'list': 'Categoría - Search Result'},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': search_key,
                                'variant': '(not available)',
                                'position': $position ,
                                'dimension1': descuento_string
                            }]
                        }
                    }
                });

            });
            $('.catalogsearch-result-index .product-items .item').on('click', '.product-item-link', function (event) {
                var $item = $(this).parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )         // use this if you are using class to check
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var $items = $('.catalogsearch-result-index .product-items .item');
                var $position = -1;
                $items.each(function( index, element ) {
                    var element_product_id = $(element).find(".price-final_price").attr('data-product-id');
                    if( element_product_id == product_id ){
                        $position = index + 1;
                    }
                });

                var search_key = $('.page-title span').html();
                search_key = search_key.replace('\'','');
                search_key = search_key.replace('Resultados de búsqueda para: ','');

                dataLayer.push({
                    'event': 'productClick',
                    'ecommerce': {
                        'click': {
                            'actionField': {'list': 'Categoría - Search Result'},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': search_key,
                                'variant': '(not available)',
                                'position': $position,
                                'dimension1': descuento_string
                            }]
                        }
                    }
                });
            });

            $('.catalogsearch-result-index .product-items .item .tocart:not(.procesado)').on('click', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();
                var product_id = $item.find(".price-final_price").attr('data-product-id');
                var product_price_amount = $item.find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(this).find('.special-price').length )         // use this if you are using class to check
                {
                    var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var seccion = '';
                if( $('.cms-index-index').length ){
                    seccion = 'Home';
                }
                else{
                    seccion = $('.page-title span').html().trim();
                }
                var search_key = $('.page-title span').html();
                search_key = search_key.replace('\'','');
                search_key = search_key.replace('Resultados de búsqueda para: ','');

                dataLayer.push({
                    'event': 'addToCart',
                    'ecommerce': {
                        'currencyCode' : 'PEN',
                        'add': {
                            'actionField': {'list': 'Categoría - Search Result'},
                            'products': [{
                                'name': name,
                                'id': product_id,
                                'price': product_price_amount ,
                                'brand': '(not available)',
                                'category': search_key,
                                'variant': '(not available)',
                                'quantity' : 1,
                                'dimension1': descuento_string,
                                'dimension2': 'Lista de Productos'
                            }]
                        }
                    }
                });
                $(this).addClass("procesado");

            });
            $('.catalogsearch-result-index .product-items .item:not(.procesadof)').on('click', '.towishlist', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - Search Result',
                    'action': 'Agregar a los favoritos',
                    'label': name
                });
                $(this).addClass("procesadof");
            });
            $('.catalogsearch-result-index .product-items .item:not(.procesadoc)').on('click', '.tocompare', function (event) {
                var $item = $(this).parent().parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - Search Result',
                    'action': 'Añadir para comparar',
                    'label': name
                });
                $(this).addClass("procesadoc");
            });

            $('.catalog-category-view #limiter').on('change', function (e) {
                var selected = $(this).find(":selected").html().trim();
                var size = parseInt(selected);
                var old_size = $shown_catalog_category.length;
                if( size > old_size ){
                    var add_array = Array(size - old_size).fill(0);
                    $shown_catalog_category = $shown_catalog_category.concat(add_array);
                }
                else{
                    var new_array = $shown_catalog_category.slice(0, size);
                    $shown_catalog_category = new_array;
                }
            });

            $('.catalogsearch-result-index #limiter').on('change', function (e) {
                var selected = $(this).find(":selected").html().trim();
                var size = parseInt(selected);

                var old_size = $shown_catalog_search.length;
                if( size > old_size ){
                    var add_array = Array(size - old_size).fill(0);
                    $shown_catalog_search = $shown_catalog_search.concat(add_array);
                }
                else{
                    var new_array = $shown_catalog_search.slice(0, size);
                    $shown_catalog_search = new_array;
                }
            });

            $('.catalog-category-view #sorter').on('change', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                var selected = $(this).find(":selected").html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar Orden',
                    'label': selected
                });

            });
            $('.catalogsearch-result-index #sorter').on('change', function (e) {
                //console.log(this);
                var selected = $(this).find(":selected").html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - Search Result',
                    'action': 'Aplicar Orden',
                    'label': selected
                });

            });

            $('.catalog-category-view .modes .mode-list').on('click', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar vista de:',
                    'label': 'Lista'
                });
            });
            $('.catalog-category-view .modes .mode-grid').on('click', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar vista de:',
                    'label': 'Parrilla'
                });
            });

            $('.catalogsearch-result-index .modes .mode-list').on('click', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar vista de:',
                    'label': 'Lista'
                });
            });
            $('.catalogsearch-result-index .modes .mode-grid').on('click', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar vista de:',
                    'label': 'Parrilla'
                });
            });

            $('.catalog-category-view .filter-options-content .items .item a').on('click', function (e) {
                //console.log(this);
                var title = $('.page-title span').html().trim();
                var filter = $(this)
                    .clone()    //clone the element
                    .children() //select all the children
                    .remove()   //remove all the children
                    .end()  //again go back to selected element
                    .text();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - ' + title,
                    'action': 'Aplicar filtro:',
                    'label': filter.trim()
                });
            });

            $('.catalogsearch-result-index .filter-options-content .items .item a').on('click', function (e) {

                var filter = $(this)
                    .clone()    //clone the element
                    .children() //select all the children
                    .remove()   //remove all the children
                    .end()  //again go back to selected element
                    .text();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Categoría - Search Result',
                    'action': 'Aplicar filtro:',
                    'label': filter.trim()
                });
            });

            // 4.5 Producto Detalle - Agregar al carrito

            if( $('.catalog-product-view').length == 0){
                /*

                $('#smcqp-container .smcqp-continue:not(.procesado)').on('click', function (event) {
                    var title = $('.page-title span').html().trim();
                    dataLayer.push({
                        'event': 'virtualEvent',
                        'category': 'Detalle de Producto',
                        'action': 'Añadiste a tu carrito de compras',
                        'label': 'Continuar'
                    });
                    $(this).addClass("procesado");
                });

                $('#smcqp-container .smcqp-view-cart:not(.procesado)').on('click', function (event) {
                    var title = $('.page-title span').html().trim();
                    dataLayer.push({
                        'event': 'virtualEvent',
                        'category': 'Detalle de Producto',
                        'action': 'Añadiste a tu carrito de compras',
                        'label': 'Ir al carrito'
                    });
                    $(this).addClass("procesado");
                });*/
            }



            //5.1 Carrito de Compras - Ver y editar carrito
            $('#minicart-content-wrapper .block-content .actions .secondary .viewcart:not(.procesado)').on('click', function (event) {
                //console.log('minicart load');
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Ver y Editar Mi Carrito',
                    'label': '(not available)'
                });
                $(this).addClass("procesado");
            });

            //5.2 Carrito de Compras - Realizar pedido
            $('#top-cart-btn-checkout:not(.procesado)').on('click', function (event) {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Realizar Pedido',
                    'label': 'Pop-up Carrito de Compras'
                });

                $(this).addClass("procesado");
            });

            //5.4 Carrito de Compras - A la lista de deseos
            $('.checkout-cart-index #shopping-cart-table .item .item-actions .action-towishlist:not(.procesado)').on('click', function (event) {
                var $item = $(this).parent().parent().parent().parent();
                var product_name = $item.find(".product-item-name a").html();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Agregar a los favoritos',
                    'label': product_name
                });
                $(this).addClass("procesado");

            });

            /*
            //5.6 Carrito de Compras -Eliminar producto del carrito
            $('.checkout-cart-index #shopping-cart-table .item:not(.procesadodel)').on('click', '.item-actions .action-delete', function (event) {
                var $item = $(this).parent().parent().parent().parent();
                var product_name = $item.find(".product-item-name a").html();
                var produt_price = $item.find(".cart-price .price").html();
                var product_qty = $item.find(".qty .input-text").val();

                dataLayer.push({
                    'event': 'removeFromCart',
                    'ecommerce': {
                        'remove': {
                            'products': [{
                                'name': product_name,
                                'id': '(not available)',
                                'price': produt_price,
                                'brand': '(not available)',
                                'category': '(not available)',
                                'variant': '(not available)',
                                'quantity': product_qty,
                                'dimension1': '(not available)',
                                'dimension2': 'Carrito de compras'
                            }]
                        }
                    }
                });

                $item.addClass("procesadodel");
            });*/

            $('body').on('click', '.action.checkout:not(.procesado)', function(e) {
                //let _url = $(this).attr('href');
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Realizar Pedido',
                    'label': 'Pop-up Carrito de Compras'
                });
                //window.location.href = _url;
                //return false;
                $(this).addClass("procesado");
            });

            /*
            $('.cart-summary .checkout .action.primary.checkout:not(.procesado)').on('click', function(e) {
                //let _url = $(this).attr('href');
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Carrito de Compras',
                    'action': 'Realizar Pedido',
                    'label': '(not available)'
                });
                //window.location.href = _url;
                //return false;
                $(this).addClass("procesado");
            });*/

            //6.1
            var shipping = $('.checkout-index-index #shipping:not(.procesado)');
            //console.log(shipping);
            if( shipping.length ){
                var is_shipping = $('.checkout-index-index #shipping').attr('style');
                if( is_shipping === 'display: none;' || is_shipping === 'opacity: 1;' || is_shipping !== undefined ){
                }
                else{
                    var $items_in_cart = $(".checkout-index-index .items-in-cart .minicart-items .product-item");
                    let product_impressions = new Array();
                    $items_in_cart.each(function(index, element ) {
                        var name = $(element).find('.product-item-name').html().trim();
                        var product_id = '(not available)';
                        var product_price_amount = $(element).find('.cart-price .price').html().trim();
                        product_price_amount = product_price_amount.substr(2);
                        product_price_amount = product_price_amount.replace(',','.');

                        var qty = $(element).find('.details-qty .value').html().trim();

                        var descuento_string = '';
                        if( $(element).find('.special-price').length )
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'quantity': parseInt(qty),
                            'dimension1': descuento_string
                        }
                        product_impressions.push(product_impression);

                    });
                    if( product_impressions.length != 0 ){
                        dataLayer.push({
                            'event': 'checkout',
                            'ecommerce': {
                                'checkout': {
                                    'actionField': {'step': 1},
                                    'products': product_impressions
                                }
                            }
                        });
                    }
                    $(shipping).addClass("procesado");
                }
            }


            //6.2
            $("#shipping-method-buttons-container .primary .continue:not(.procesado)").on('click', function (event) {
                var metodo = $("#checkout-step-shipping_method .table-checkout-shipping-method .row .col-method .radio:checked");
                var row = metodo.parent().parent();

                var precio = $(row).find('.col-price .price .price').html().trim();
                var tipo_metodo = $(row).find('.col-carrier').html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Checkout - Envío',
                    'action': 'Siguiente',
                    'label': precio + '-' + tipo_metodo,
                });
                $(this).addClass("procesado");
            });

            //7.1
            var payment = $('.checkout-index-index #payment:not(.procesado)');
            //console.log(payment);
            if( payment.length ){
                var is_payment = $('.checkout-index-index #payment').attr('style');
                //console.log('is_payment');
                console.log(is_payment);
                if( is_payment === 'display: none;' || is_payment === undefined ){
                    //console.log('b');
                }
                else{
                    //console.log('a');
                    var $items_in_cart = $(".checkout-index-index .items-in-cart .minicart-items .product-item");
                    let product_impressions = new Array();
                    $items_in_cart.each(function(index, element ) {
                        var name = $(element).find('.product-item-name').html().trim();
                        var product_id = '(not available)';
                        var product_price_amount = $(element).find('.cart-price .price').html().trim();
                        product_price_amount = product_price_amount.substr(2);
                        product_price_amount = product_price_amount.replace(',','.');

                        var qty = $(element).find('.details-qty .value').html().trim();

                        var descuento_string = '';
                        if( $(element).find('.special-price').length )
                        {
                            var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                            product_price_amount = product_special_price;
                            var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                            var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                            descuento_string = Math.round(descuento) + '% OFF';
                        }
                        else{
                            descuento_string = '0% OFF';
                        }

                        let product_impression = {
                            'name': name,
                            'id': product_id,
                            'price': product_price_amount,
                            'brand': '(not available)',
                            'category': '(not available)',
                            'variant': '(not available)',
                            'quantity': parseInt(qty),
                            'dimension1': descuento_string
                        }
                        product_impressions.push(product_impression);

                    });
                    if( product_impressions.length != 0 ){
                        dataLayer.push({
                            'event': 'checkout',
                            'ecommerce': {
                                'checkout': {
                                    'actionField': {'step': 2},
                                    'products': product_impressions
                                }
                            }
                        });
                    }
                    $(payment).addClass("procesado");
                }
            }


            /*
            //7.2
            $('#payment .payment-methods .payment-group .payment-method .payment-method-content .actions-toolbar .primary button:not(.procesado)').on('click', function (event) {
                console.log('clicked payment method');
                console.log(this);

                $(this).addClass("procesado");
                //console.log(window.checkoutConfig.payment.visanet_pay.quote_id);
                console.log('payments values');
                console.log(window.checkoutConfig.payment);
            });
            */

            //10
            $('#searchbox_autocomplete ul li').on('click', function (event) {
                var opcion = $(this).find('.qs-option-name').html()
                var categoria = $('#searchbox_mini_form .search .control .searchbox-cat').find(":selected").html().trim();
                if( categoria != 'Categorías'){
                    categoria = categoria.substr(4);
                }

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Buscador',
                    'action': 'Seleccionar resultado de búsqueda',
                    'label': categoria + ' - ' + opcion
                });

            });

            //11.3

            //11.7 Eliminar de la lista de deseos
            $('.wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item .product-item-actions .delete').on('click', function (event) {
                var $item = $(this).parent().parent().parent().parent();
                var name = $item.find(".product-item-link").html().trim();

                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Página de Usuario',
                    'action': 'Eliminar Productos en Mi Lista de Deseos:',
                    'label': name
                });
            });

            //12.1

            //checkout-cart-index
            /*
            $('.checkout-cart-index .block-authentication .block-new-customer .primary .action-register:not(.procesado)').on('click', function (event) {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Página de Usuario',
                    'action': 'Crea tu cuenta / Inicia sesión',
                    'label': 'Crea tu cuenta'
                });
                $(this).addClass("procesado");
            });
            $('.checkout-cart-index .block-authentication .block-customer-login .primary .action-login:not(.procesado)').on('click', function (event) {
                var form = $('#login-form');
                if( $(form).valid() ){
                    dataLayer.push({
                        'event': 'virtualEvent',
                        'category': 'Página de Usuario',
                        'action': 'Crea tu cuenta / Inicia sesión',
                        'label': 'Iniciar sesión'
                    });
                }
                $(this).addClass("procesado");
            });
            $('.checkout-cart-index .block-authentication .block-customer-login .secondary .action:not(.procesado)').on('click', function (event) {
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Página de Usuario',
                    'action': 'Crea tu cuenta / Inicia sesión',
                    'label': '¿Olvidaste tu contraseña?'
                });
                $(this).addClass("procesado");
            });*/



        },
        success:function(){

        }
    });

    $(window).scroll(function(event){

        if( $('.cms-index-index').length ){

            if( typeof $home_jalavista1 !== "undefined" ){
                $home_jalavista1.each(function( index, element ) {
                    if( $shown_home_jalavista1[index] == 0 && isOnScreen(element) ){
                        var $position = index + 1;
                        var banner_url_img = $(element).find("img").attr('src');
                        var banner_name = $(element).find("a").attr('title');

                        dataLayer.push({
                            'event': 'promotionView',
                            'ecommerce': {
                                'promoView': {
                                    'promotions': [{
                                        'id': 'JV1-' + $position,
                                        'name': banner_name,
                                        'position': 'Home - Banner Novedades - ' + $position,
                                        'creative': banner_url_img
                                    }]
                                }
                            }
                        });
                        $shown_home_jalavista1[index] = 1;
                    }
                });
            }

            if( typeof $home_jalavista2 !== "undefined" ){
                $home_jalavista2.each(function( index, element ) {
                    if( $shown_home_jalavista2[index] == 0 && isOnScreen(element) ){
                        var $position = index + 1;
                        var banner_url_img = $(element).find("img").attr('src');
                        var banner_name = $(element).find("a").attr('title');

                        dataLayer.push({
                            'event': 'promotionView',
                            'ecommerce': {
                                'promoView': {
                                    'promotions': [{
                                        'id': 'JV2-' + $position,
                                        'name': banner_name,
                                        'position': 'Home - Banner Promociones - ' + $position,
                                        'creative': banner_url_img
                                    }]
                                }
                            }
                        });
                        $shown_home_jalavista2[index] = 1;
                    }
                });

            }

            if( typeof $home_jalavista3 !== "undefined" ){

                $home_jalavista3.each(function( index, element ) {
                    if( $shown_home_jalavista3[index] == 0 && isOnScreen(element) ){
                        var $position = index + 1;
                        var banner_url_img = $(element).find("img").attr('src');
                        var banner_name = $(element).find("a").attr('title');

                        dataLayer.push({
                            'event': 'promotionView',
                            'ecommerce': {
                                'promoView': {
                                    'promotions': [{
                                        'id': 'JV3-' + $position,
                                        'name': banner_name,
                                        'position': 'Home - Banner Promociones - ' + $position,
                                        'creative': banner_url_img
                                    }]
                                }
                            }
                        });
                        $shown_home_jalavista3[index] = 1;
                    }
                });
            }

            var $active_items_gaming = $(class_gaming + " .owl-item.active");
            product_impressions = new Array();
            $active_items_gaming.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Gaming',
                    'variant': '(not available)',
                    'list': 'Home - Novedades - Gaming',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_novedades_gaming[position-1] === 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_novedades_gaming[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

            var $active_items_promociones = $(class_promociones + " .owl-item.active");
            product_impressions = new Array();
            $active_items_promociones.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Promociones',
                    'variant': '(not available)',
                    'list': 'Home - Promociones',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_promociones[position-1] === 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_promociones[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

            var $active_items_sillas_gamer = $(class_sillas_gamer + " .owl-item.active");
            product_impressions = new Array();
            $active_items_sillas_gamer.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Sillas Gamer',
                    'variant': '(not available)',
                    'list': 'Home - Sillas Gamer',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_sillas_gamer[position-1] === 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_sillas_gamer[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }

            var $active_items_laptops = $(class_ex_online_laptops + " .owl-item.active");
            product_impressions = new Array();
            $active_items_laptops.each(function(index, element ) {
                var name = $(element).find(".product-item-link").html().trim();
                var product_id = $(element).find(".price-final_price").attr('data-product-id');
                var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                var descuento_string = '';
                if( $(element).find('.special-price').length )
                {
                    var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                    product_price_amount = product_special_price;
                    var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                    descuento_string = Math.round(descuento) + '% OFF';
                }
                else{
                    descuento_string = '0% OFF';
                }

                var position = index + 1;

                let product_impression = {
                    'name': name,
                    'id': product_id,
                    'price': product_price_amount,
                    'brand': '(not available)',
                    'category': 'Laptops',
                    'variant': '(not available)',
                    'list': 'Home - Exclusivo Online - Laptops',
                    'position': position,
                    'dimension1': descuento_string
                };
                if( shown_ex_online_laptops[position-1] === 0 && isOnScreen(element) && $(element).is(":visible") ) {
                    product_impressions.push(product_impression);
                    shown_ex_online_laptops[position-1] = 1;
                }
            });
            if( product_impressions.length != 0 ){
                dataLayer.push({
                    'event': 'productImpression',
                    'ecommerce': {
                        'currencyCode': 'PEN',
                        'impressions': product_impressions
                    }
                });
            }
        }

        if( $('.catalog-category-view').length ){
            var product_impressions = new Array();
            if( typeof $catalog_category !== "undefined" ){
                $catalog_category.each(function( index, element ) {
                    var name = $(element).find(".product-item-link").html().trim();
                    var product_id = $(element).find(".price-final_price").attr('data-product-id');
                    var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento_string = '';
                    if( $(element).find('.special-price').length )         // use this if you are using class to check
                    {
                        var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                        product_price_amount = product_special_price;
                        var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                        descuento_string = Math.round(descuento) + '% OFF';
                    }
                    else{
                        descuento_string = '0% OFF';
                    }
                    var category = $('.page-title span').html();
                    var category_items = $('.breadcrumbs .items .item');
                    var category = '(not available)';
                    if( category_items.length >= 2){
                        category = category_items[1].innerText;
                    }

                    var position = index + 1;

                    let product_impression = {
                        'name': name,
                        'id': product_id,
                        'price': product_price_amount,
                        'brand': '(not available)',
                        'category': category,
                        'variant': '(not available)',
                        'list': 'Categoría - ' + category,
                        'position': position,
                        'dimension1': descuento_string
                    };
                    if( $shown_catalog_category[position-1] == 0 && isOnScreen(element) ) {
                        product_impressions.push(product_impression);
                        $shown_catalog_category[position-1] = 1;
                    }
                });
                if( product_impressions.length != 0 ){
                    dataLayer.push({
                        'event': 'productImpression',
                        'ecommerce': {
                            'currencyCode': 'PEN',
                            'impressions': product_impressions
                        }
                    });
                }
            }
        }

        if( $('.catalogsearch-result-index').length ){
            product_impressions = new Array();
            if( typeof $catalog_search !== "undefined" ){
                $catalog_search.each(function( index, element ) {
                    var name = $(element).find(".product-item-link").html().trim();
                    var product_id = $(element).find(".price-final_price").attr('data-product-id');
                    var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento_string = '';
                    if( $(this).find('.special-price').length )         // use this if you are using class to check
                    {
                        var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                        product_price_amount = product_special_price;
                        var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                        descuento_string = Math.round(descuento) + '% OFF';
                    }
                    else{
                        descuento_string = '0% OFF';
                    }
                    var search_key = $('.page-title span').html();
                    search_key = search_key.replace('\'','');
                    search_key = search_key.replace('\'','');
                    search_key = search_key.replace('Resultados de búsqueda para: ','');

                    var position = index + 1;

                    let product_impression = {
                        'name': name,
                        'id': product_id,
                        'price': product_price_amount,
                        'brand': '(not available)',
                        'category': search_key,
                        'variant': '(not available)',
                        'list': 'Categoría - Search Result',
                        'position': position,
                        'dimension1': descuento_string
                    };
                    if( $shown_catalog_search[position-1] == 0 && isOnScreen(element) ) {
                        product_impressions.push(product_impression);
                        $shown_catalog_search[position-1] = 1;
                    }
                });
                if( product_impressions.length != 0 ){
                    dataLayer.push({
                        'event': 'productImpression',
                        'ecommerce': {
                            'currencyCode': 'PEN',
                            'impressions': product_impressions
                        }
                    });
                }
            }
        }

        //Detalle de producto - Productos relacionados
        if( $('.catalog-product-view').length ){
            var $active_items = $(".catalog-product-view .products-grid .owl-carousel .owl-item.active");
            product_impressions = new Array();
            if( typeof $active_items !== "undefined" ){
                $active_items.each(function(index, element ) {
                    var name = $(element).find(".product-item-link").html().trim();
                    var product_id = $(element).find(".price-final_price").attr('data-product-id');
                    var product_price_amount = $(element).find(".price-final_price .price-wrapper").attr('data-price-amount');
                    var descuento_string = '';
                    if( $(element).find('.special-price').length )
                    {
                        var product_special_price = $(element).find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                        product_price_amount = product_special_price;
                        var product_old_price = $(element).find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                        descuento_string = Math.round(descuento) + '% OFF';
                    }
                    else{
                        descuento_string = '0% OFF';
                    }
                    var category_items = $('.breadcrumbs .items .item');
                    var category = '(not available)';
                    if( category_items.length >= 3){
                        category = category_items[1].innerText;
                    }

                    var position = index + 1;
                    let product_impression = {
                        'name': name,
                        'id': product_id,
                        'price': product_price_amount,
                        'brand': '(not available)',
                        'category': category,
                        'variant': '(not available)',
                        'list': 'Detalle de producto - Productos relacionado',
                        'position': position,
                        'dimension1': descuento_string
                    };

                    if( $shown_prods_relacionados[position-1] == 0 && isOnScreen(element) ) {
                        product_impressions.push(product_impression);
                        $shown_prods_relacionados[position-1] = 1;
                    }
                });
                if( product_impressions.length != 0 ){
                    dataLayer.push({
                        'event': 'productImpression',
                        'ecommerce': {
                            'currencyCode': 'PEN',
                            'impressions': product_impressions
                        }
                    });
                }
            }
        }

        if( $('.wishlist-index-index').length ){
            product_impressions = new Array();
            if( typeof $wish_list !== "undefined" ){
                $wish_list.each(function( index, element ) {
                    var $item = $(element);
                    var name = $item.find(".product-item-link").html().trim();
                    var product_id = $item.find(".price-configured_price").attr('data-product-id');
                    var product_price_amount = $item.find(".price-configured_price .price-wrapper").attr('data-price-amount');
                    var descuento_string = '';
                    if( $item.find('.special-price').length )
                    {
                        var product_special_price = $item.find(".special-price .price-final_price .price-wrapper").attr('data-price-amount');
                        product_price_amount = product_special_price;
                        var product_old_price = $item.find(".old-price .price-final_price .price-wrapper").attr('data-price-amount');
                        var descuento = ((product_old_price-product_special_price)/product_old_price)*100;
                        descuento_string = Math.round(descuento) + '% OFF';
                    }
                    else{
                        descuento_string = '0% OFF';
                    }

                    var $items = $(".wishlist-index-index .form-wishlist-items .products-grid .product-items .product-item");
                    var position = -1;
                    $items.each(function( index, element ) {
                        var element_product_id = $(element).find(".price-box").attr('data-product-id');
                        if( element_product_id == product_id ){
                            position = index + 1;
                        }
                    });

                    let product_impression = {
                        'name': name,
                        'id': product_id,
                        'price': product_price_amount,
                        'brand': '(not available)',
                        'category': '(not available)',
                        'variant': '(not available)',
                        'list': 'Mi Lista de Deseos',
                        'position': position,
                        'dimension1': descuento_string
                    };

                    if( $shown_wish_list[position-1] == 0 && isOnScreen(element) ) {
                        product_impressions.push(product_impression);
                        $shown_wish_list[position-1] = 1;
                    }

                });
                if( product_impressions.length != 0 ){
                    dataLayer.push({
                        'event': 'productImpression',
                        'ecommerce': {
                            'currencyCode': 'PEN',
                            'impressions': product_impressions
                        }
                    });
                }
            }

        }

    });

    function isOnScreen(elm) {
        var rect = elm.getBoundingClientRect();
        var viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight);
        return !(rect.bottom < 0 || rect.top - viewHeight >= 0);
    }

    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
        return false;
    };

    function getCookie(name) {
        var re = new RegExp(name + "=([^;]+)");
        var value = re.exec(document.cookie);
        return (value != null) ? unescape(value[1]) : null;
    }
    function getClientID() {
        try {
            var cookie = getCookie("_ga").split(".");
            return cookie[2] + "." + cookie[3];
        } catch(e) {
            console.log("No Universal Analytics cookie found");
        }
    }

    function sendDataFormErrors(_fields) {
        let _fchecks = [];
        for(let f of _fields) {
            if(f.value == '') {
                _fchecks.push(f);
                dataLayer.push({
                    'event': 'virtualEvent',
                    'category': 'Checkout - Envío',
                    'action': 'Errores en formulario',
                    'label': `${f.name}`
                });
            }
        }
    }


});
