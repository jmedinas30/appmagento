<?php
/**
 * Manage script.phtml and noscript.phtml displaying.
 *
 * This block single purpose is to fetch configuration fields from the back-office and to make them available to
 * templates.
 *
 * @license http://www.opensource.org/licenses/mit-license.php MIT (see the LICENSE file)
 * @author Kevin Hagner
 */

namespace Spydemon\GoogleTagManager\Block;

use Magento\Framework\View\Element\Template as InheritedClass;

class Gtm extends InheritedClass
{

    /**
     * @return string
     */
    public function getGtmId()
    {
        return $this->_scopeConfig->getValue('google/gtm/container_id');
    }

    /**
     * @return string, html
     */
    protected function _toHtml()
    {
        return $this->_scopeConfig->getValue('google/gtm/enabled')
            ? parent::_toHtml()
            : '';
    }
}
