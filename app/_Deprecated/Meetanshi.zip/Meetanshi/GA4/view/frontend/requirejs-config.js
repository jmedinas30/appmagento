var config = {
    map: {
        '*': {
            'Magento_SalesRule/js/action/set-coupon-code': 'Meetanshi_GA4/js/action/set-coupon-code',
            'Magento_SalesRule/js/action/cancel-coupon': 'Meetanshi_GA4/js/action/cancel-coupon'
        }
    }
};
