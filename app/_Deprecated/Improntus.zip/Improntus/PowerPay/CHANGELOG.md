CHANGELOG
---------

### 1.1.0 (2023-04-21)

* Initial release

### 1.1.3 (2023-07-17)

* Cleanup
* Added agreement block in checkout KO template

### 1.1.4 (2023-10-03)

* Minor retrocompatibility fixes
