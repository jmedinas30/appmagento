<?php
namespace Vexsoluciones\Delivery\Api;
 
interface DeliveryInterface
{
    /**
     * Returns greeting message to user
     *
     * @api
     * @return string Greeting message with users name.
     */
    public function listarhorario();
    
    
}