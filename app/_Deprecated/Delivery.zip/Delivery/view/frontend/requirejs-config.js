 var config = {
    map: {
        '*': {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Vexsoluciones_Delivery/js/model/shipping-save-processor/default",
            "Magento_Checkout/js/model/shipping-save-processor/payload-extender" : "Vexsoluciones_Delivery/js/model/shipping-save-processor/payload-extender",
            'Magento_Checkout/js/model/address-converter': 'Vexsoluciones_Delivery/js/model/address-converter',
            'Magento_Checkout/template/billing-address/details.html': 'Vexsoluciones_Delivery/template/billing-address/details.html',
            'Magento_Checkout/js/view/shipping': 'Vexsoluciones_Delivery/js/view/shipping',
            'Magento_Checkout/template/shipping-address/address-renderer/default.html': 'Vexsoluciones_Delivery/template/checkout/shipping-address/address-renderer/default.html',
            'Magento_Checkout/template/shipping-information/address-renderer/default.html': 'Vexsoluciones_Delivery/template/shipping-information/address-renderer/default.html',
            "Magento_Checkout/template/shipping.html" : "Vexsoluciones_Delivery/template/shipping.html"
        }
    }
};
 